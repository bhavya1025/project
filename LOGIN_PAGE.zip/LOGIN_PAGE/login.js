const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

function ValidateEmail(inputText)
{
var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@bmsce.ac.in$/;
if(inputText.value.match(mailformat))
{
	return (true);
}
else
{
	alert("Please enter a valid bmsce Email!");
	document.getElementById('EmailText').value = '';
	return (false);
}
}
